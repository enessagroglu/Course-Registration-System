public class Furkan_Cetin {
    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}