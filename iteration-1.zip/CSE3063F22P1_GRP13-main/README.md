# CSE3063F22P1_GRP13

1- 150119725 Enes Sağıroğlu
2- 150119631 Utku Baygüven
3- 150119555 Ömercan Sabun
4- 150119041 İpek Külhan
5- 150118063 Mehmet Selim Can
6- 150119669 Melis Çırpan
7- 150119807 Yasin Enes Şişik
8- 150119736 Mehmet Akif Şahin
9- 150119657 Abdulkerim Talha Timur
10- 150119627 Furkan Çetin
11- 150119808 Emre Demir
